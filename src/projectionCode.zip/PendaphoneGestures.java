import org.apache.commons.math.geometry.Vector3D;

import java.awt.AWTException;
import java.awt.Robot;


public class PendaphoneGestures 
{
	Vector3D rightBall;
	Vector3D leftBall;
	
	Robot robot;
	DisplayPlane plane;
	
	public final static int CALIBRATION = 0;
	public final static int INTERACTION = 1;
	
	public static int mode = CALIBRATION;
	
	boolean pressed = false;
	
	public PendaphoneGestures()
	{
		
		rightBall = new Vector3D(0,0);
		leftBall = new Vector3D(0,0);
	
		MovingBallListener mbl = new MovingBallListener(this);
		mbl.initConnection();
		
		try {
			robot = new Robot();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void updateLocation(double[] tokens)
	{
		// have to reverse the direction of the x
		rightBall = new Vector3D(tokens[2], new Vector3D(tokens[0], tokens[1]));
		leftBall = new Vector3D(tokens[5], new Vector3D(tokens[3], tokens[4]));
		
		if (mode == INTERACTION && tokens[2] < .98)
		{
			Vector3D projection = plane.projectToPlane(rightBall);
			//Vector3D projection = rightBall;
			robot.mouseMove((int)plane.translatePlaneX(projection), (int)plane.translatePlaneY(projection));
		//	System.out.println("x,y = " + (int)plane.translatePlaneX(projection) + "," +  (int)plane.translatePlaneY(projection));

		}
		if (mode == INTERACTION && pressed == false && plane.getD() - rightBall.getNorm() < 0.03)
		{	robot.mousePress(0);
			pressed = true;
		}
		else if (mode == INTERACTION && pressed == true && plane.getD() - rightBall.getNorm() >= 0.03)
		{
			robot.mouseRelease(0);
			pressed = false;
		}
		
	}
	
	public Vector3D getRightLocation()
	{
		return rightBall;
	}
	
	public void setDisplayPlane(DisplayPlane dp)
	{
		this.plane = dp;
		mode = INTERACTION;
	}


}
