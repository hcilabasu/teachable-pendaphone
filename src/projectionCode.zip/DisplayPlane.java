
import org.apache.commons.math.geometry.Vector3D;
import java.awt.Rectangle;
import java.awt.Dimension;
import java.awt.Toolkit;


public class DisplayPlane 
{
	Vector3D bottomRight;
	Vector3D bottomLeft;
	Vector3D topLeft;
	Vector3D normalVector;
	
	Dimension realBounds;
	
	protected double distanceFromPlaneAdj;
	
	/** Display Plane constructor. Accepts a pointer to the Geogbra Interface.
	*/
	public DisplayPlane(Vector3D bottomRight, Vector3D bottomLeft, Vector3D topLeft)
	{
		this.bottomRight = bottomRight;
		this.bottomLeft = bottomLeft;
		this.topLeft = topLeft;
		this.normalVector = Vector3D.crossProduct(topLeft.subtract(bottomLeft), bottomRight.subtract(bottomLeft));
		
		realBounds = Toolkit.getDefaultToolkit().getScreenSize();

		this.distanceFromPlaneAdj = bottomLeft.getNorm();
	}
	
	public double getD()
	{
		return distanceFromPlaneAdj;
	}
	
	// projects the location of the vector to a point on the plane
	public Vector3D projectToPlane(Vector3D ball)
	{
		//point on the plane * normal vector / l * normal vector
		double scalarMultiplier = (Vector3D.dotProduct(bottomLeft, normalVector))/(Vector3D.dotProduct(ball, normalVector));				
		//System.out.println(ball.getAlpha());
		//System.out.println(ball.getDelta())
		return new Vector3D(scalarMultiplier, new Vector3D(ball.getAlpha(), ball.getDelta()));
	}
	
	public double translatePlaneX(Vector3D pointProjection)
	{
		Vector3D twoDvector = pointProjection.subtract(bottomLeft);
		double angle = Vector3D.angle(twoDvector, bottomRight.subtract(bottomLeft));
		return scaleX(twoDvector.getNorm()*Math.cos(angle));
	}
	
	public double translatePlaneY(Vector3D pointProjection)
	{
		Vector3D twoDvector = pointProjection.subtract(bottomLeft);
		double angle = Vector3D.angle(twoDvector, bottomRight.subtract(bottomLeft));
		return scaleY(twoDvector.getNorm()*Math.sin(angle));
	}	
	
	public double scaleX(double xValue)
	{
		return xValue*realBounds.getWidth()/(bottomRight.subtract(bottomLeft)).getNorm();
	}
	
	
	// have to subtract it from the height because we're doing the origin as the bottom left rather than top left
	public double scaleY(double yValue)
	{
		//System.out.println(realBounds.getHeight() - yValue*realBounds.getHeight()/(topLeft.subtract(bottomLeft)).getNorm());
		return realBounds.getHeight() - yValue*realBounds.getHeight()/(topLeft.subtract(bottomLeft)).getNorm();
	}
	
}
