import javax.swing.JFrame;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.BoxLayout;

import org.apache.commons.math.geometry.Vector3D;


public class CalibrationPanel extends JPanel
{
	PendaphoneGestures gest;
	
	public CalibrationPanel(PendaphoneGestures pg)
	{
		gest = pg;
	}
	
	public DisplayPlane startCalibration()
	{
		JOptionPane.showMessageDialog(this,"Move the pendaphone to the bottom right corner of the screen, then hit OK.");
		Vector3D bottomRight = gest.getRightLocation();
		System.out.println("BottomRight location: " + bottomRight.toString());
		JOptionPane.showMessageDialog(this, "Move the pendaphone to the bottom left corner of the screen, then hit OK.");
		Vector3D bottomLeft = gest.getRightLocation();
		System.out.println("BottomLeft location: " + bottomLeft.toString());
		JOptionPane.showMessageDialog(this, "Move the pendaphone to the top left corner of the screen, then hit OK.");
		Vector3D topLeft = gest.getRightLocation();
		System.out.println("TopLeft location: " + topLeft.toString());
		return new DisplayPlane(bottomRight, bottomLeft, topLeft); 
	}
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame();
		PendaphoneGestures pg = new PendaphoneGestures();
		CalibrationPanel cp = new CalibrationPanel(pg);
		frame.add(cp);
		DisplayPlane dp = cp.startCalibration();
		pg.setDisplayPlane(dp);
	}
	
}
